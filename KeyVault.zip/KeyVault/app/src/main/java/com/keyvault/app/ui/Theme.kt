package com.keyvault.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Light theme — clean white with a royal-blue accent
private val Light = lightColorScheme(
    primary = Color(0xFF2F5BEA),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE5FF),
    onPrimaryContainer = Color(0xFF0B2170),
    secondary = Color(0xFF5B6478),
    secondaryContainer = Color(0xFFE3E7F1),
    onSecondaryContainer = Color(0xFF1A2030),
    background = Color(0xFFF6F7FB),
    onBackground = Color(0xFF15181F),
    surface = Color(0xFFF6F7FB),
    onSurface = Color(0xFF15181F),
    surfaceVariant = Color(0xFFE9ECF4),
    onSurfaceVariant = Color(0xFF555C6C),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFEEF1F8),
    outline = Color(0xFFC3C8D4),
    outlineVariant = Color(0xFFDDE1EA),
    error = Color(0xFFD32F2F),
)

// Dark theme — deep charcoal with a soft-blue accent
private val Dark = darkColorScheme(
    primary = Color(0xFF9DB4FF),
    onPrimary = Color(0xFF0A1C5A),
    primaryContainer = Color(0xFF243C8C),
    onPrimaryContainer = Color(0xFFDDE5FF),
    secondary = Color(0xFFB5BCCC),
    secondaryContainer = Color(0xFF2A303D),
    onSecondaryContainer = Color(0xFFDDE2EE),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE4E6EC),
    surface = Color(0xFF0F1115),
    onSurface = Color(0xFFE4E6EC),
    surfaceVariant = Color(0xFF242833),
    onSurfaceVariant = Color(0xFFA8AEBC),
    surfaceContainer = Color(0xFF181B22),
    surfaceContainerLow = Color(0xFF181B22),
    surfaceContainerHigh = Color(0xFF20242D),
    outline = Color(0xFF4A505E),
    outlineVariant = Color(0xFF2E333E),
    error = Color(0xFFFF8A80),
)

@Composable
fun KeyVaultTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
