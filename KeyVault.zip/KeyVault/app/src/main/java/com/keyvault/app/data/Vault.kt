package com.keyvault.app.data

import android.app.Application
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

fun newId(): String = UUID.randomUUID().toString()

/** One "name : content" line, e.g. "User ID : abc@gmail.com". */
data class Field(
    val id: String = newId(),
    val name: String = "",
    val value: String = "",
    val secret: Boolean = false,
)

/** A saved login: a title plus any number of fields. */
data class Account(
    val id: String = newId(),
    val title: String = "",
    val fields: List<Field> = emptyList(),
    val updated: Long = System.currentTimeMillis(),
)

data class Note(
    val id: String = newId(),
    val title: String = "",
    val body: String = "",
    val updated: Long = System.currentTimeMillis(),
)

data class VaultData(
    val accounts: List<Account> = emptyList(),
    val notes: List<Note> = emptyList(),
    val profile: List<Field> = defaultProfile(),
) {
    companion object {
        fun defaultProfile() = listOf(
            Field(name = "Full Name"), Field(name = "Mobile"),
            Field(name = "Email"), Field(name = "Address"),
        )
    }
}

/** Text produced by "Master Copy": title + every field name and value. */
fun masterText(title: String?, fields: List<Field>): String = buildString {
    if (!title.isNullOrBlank()) appendLine(title)
    fields.filter { it.name.isNotBlank() || it.value.isNotBlank() }
        .forEach { appendLine("${it.name}: ${it.value}") }
}.trimEnd()

// ---------- JSON ----------
private fun Field.toJson() = JSONObject().put("id", id).put("name", name).put("value", value).put("secret", secret)
private fun JSONObject.toField() = Field(optString("id", newId()), optString("name"), optString("value"), optBoolean("secret"))
private fun List<Field>.toJson() = JSONArray().also { a -> forEach { a.put(it.toJson()) } }
private fun JSONArray?.toFields(): List<Field> =
    if (this == null) emptyList() else (0 until length()).map { getJSONObject(it).toField() }

private fun VaultData.toJson(): JSONObject = JSONObject()
    .put("version", 1)
    .put("accounts", JSONArray().also { a ->
        accounts.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("updated", it.updated).put("fields", it.fields.toJson()))
        }
    })
    .put("notes", JSONArray().also { a ->
        notes.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updated", it.updated)) }
    })
    .put("profile", profile.toJson())

private fun JSONObject.toVault(): VaultData {
    val acc = optJSONArray("accounts")
    val notes = optJSONArray("notes")
    return VaultData(
        accounts = if (acc == null) emptyList() else (0 until acc.length()).map {
            val o = acc.getJSONObject(it)
            Account(o.optString("id", newId()), o.optString("title"), o.optJSONArray("fields").toFields(), o.optLong("updated"))
        },
        notes = if (notes == null) emptyList() else (0 until notes.length()).map {
            val o = notes.getJSONObject(it)
            Note(o.optString("id", newId()), o.optString("title"), o.optString("body"), o.optLong("updated"))
        },
        profile = optJSONArray("profile")?.toFields() ?: VaultData.defaultProfile(),
    )
}

/**
 * Stores everything in one file encrypted with AES-256-GCM.
 * The key lives in the Android Keystore and never leaves the phone.
 */
class VaultStore(context: Context) {
    private val dir = context.filesDir
    private val file = File(dir, "vault.bin")

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun load(): VaultData {
        if (!file.exists()) return VaultData()
        return try {
            val bytes = file.readBytes()
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes, 0, IV_LEN))
            val plain = cipher.doFinal(bytes, IV_LEN, bytes.size - IV_LEN)
            JSONObject(String(plain, Charsets.UTF_8)).toVault()
        } catch (e: Exception) {
            // Never silently overwrite data we could not read: keep a copy aside.
            file.renameTo(File(dir, "vault_unreadable_${System.currentTimeMillis()}.bin"))
            VaultData()
        }
    }

    fun save(data: VaultData) {
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val out = cipher.iv + cipher.doFinal(data.toJson().toString().toByteArray(Charsets.UTF_8))
        val tmp = File(dir, "vault.tmp")
        tmp.writeBytes(out)
        tmp.renameTo(file) // atomic replace
    }

    private companion object {
        const val ALIAS = "keyvault_master_key"
        const val TRANSFORM = "AES/GCM/NoPadding"
        const val IV_LEN = 12
    }
}

class VaultViewModel(app: Application) : AndroidViewModel(app) {
    private val store = VaultStore(app)
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var data by mutableStateOf(store.load())
        private set

    /** "light", "dark" or "system" */
    var themeMode by mutableStateOf(prefs.getString("theme", "system") ?: "system")
        private set

    fun setTheme(mode: String) {
        themeMode = mode
        prefs.edit().putString("theme", mode).apply()
    }

    private fun update(change: (VaultData) -> VaultData) {
        data = change(data)
        store.save(data)
    }

    fun account(id: String) = data.accounts.firstOrNull { it.id == id }
    fun note(id: String) = data.notes.firstOrNull { it.id == id }

    fun saveAccount(a: Account) = update { d ->
        d.copy(accounts = (d.accounts.filterNot { it.id == a.id } + a.copy(updated = System.currentTimeMillis()))
            .sortedBy { it.title.lowercase() })
    }
    fun deleteAccount(id: String) = update { d -> d.copy(accounts = d.accounts.filterNot { it.id == id }) }

    fun saveNote(n: Note) = update { d ->
        d.copy(notes = (d.notes.filterNot { it.id == n.id } + n.copy(updated = System.currentTimeMillis()))
            .sortedByDescending { it.updated })
    }
    fun deleteNote(id: String) = update { d -> d.copy(notes = d.notes.filterNot { it.id == id }) }

    fun saveProfile(fields: List<Field>) = update { it.copy(profile = fields) }
}
