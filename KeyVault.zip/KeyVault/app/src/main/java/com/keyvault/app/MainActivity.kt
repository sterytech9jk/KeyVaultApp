package com.keyvault.app

import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.keyvault.app.data.VaultViewModel
import com.keyvault.app.ui.AppRoot
import com.keyvault.app.ui.KeyVaultTheme
import com.keyvault.app.ui.LockScreen

/**
 * Opens behind the phone's own screen lock (PIN / pattern / password / fingerprint / face).
 * Re-locks every time the app goes to the background.
 */
class MainActivity : FragmentActivity() {

    private val vm: VaultViewModel by viewModels()
    private var unlocked by mutableStateOf(false)
    private var authInProgress = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hide content in Recent Apps and block screenshots / screen recording.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        setContent {
            val dark = when (vm.themeMode) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme()
            }
            LaunchedEffect(dark) {
                val style = if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
                else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            KeyVaultTheme(dark) {
                if (unlocked) AppRoot(vm, onLock = { unlocked = false })
                else LockScreen(onUnlock = ::authenticate)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (!unlocked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        // The PIN screen on older Android opens a separate window — don't relock for that.
        if (!isChangingConfigurations && !authInProgress) unlocked = false
    }

    private fun authenticate() {
        if (authInProgress || unlocked) return
        val allowed = BIOMETRIC_WEAK or DEVICE_CREDENTIAL

        if (BiometricManager.from(this).canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            // No screen lock set on the phone — nothing to verify against.
            Toast.makeText(this, "Set a screen lock on your phone to protect KeyVault", Toast.LENGTH_LONG).show()
            unlocked = true
            return
        }

        authInProgress = true
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authInProgress = false
                    unlocked = true
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authInProgress = false // stays on the lock screen; user can tap Unlock again
                }
            })

        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock KeyVault")
                .setSubtitle("Use your phone's screen lock")
                .setAllowedAuthenticators(allowed)
                .build()
        )
    }
}
