package com.keyvault.app.ui

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.PersistableBundle
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.keyvault.app.data.Field

/** Copies text; marked sensitive so Android 13+ hides it in the clipboard preview. */
fun copyText(context: Context, label: String, text: String) {
    val cm = context.getSystemService(ClipboardManager::class.java) ?: return
    val clip = ClipData.newPlainText(label, text)
    if (Build.VERSION.SDK_INT >= 33) {
        clip.description.extras = PersistableBundle().apply {
            putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
        }
    }
    cm.setPrimaryClip(clip)
    // Android 13+ shows its own "Copied" bubble; older versions need a toast.
    if (Build.VERSION.SDK_INT < 33) Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
}

val CardShape = RoundedCornerShape(16.dp)

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) { content() }
}

/** A read-only field row. Tap anywhere on it to copy the value. */
@Composable
fun FieldRow(field: Field) {
    val ctx = LocalContext.current
    var reveal by remember { mutableStateOf(false) }
    val label = field.name.ifBlank { "Value" }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { copyText(ctx, label, field.value) }
            .padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val shown = if (field.secret && !reveal) "•".repeat(field.value.length.coerceIn(6, 12)) else field.value
            Text(
                shown.ifEmpty { "—" },
                style = MaterialTheme.typography.bodyLarge,
                fontFamily = if (field.secret) FontFamily.Monospace else null,
                maxLines = 3, overflow = TextOverflow.Ellipsis,
            )
        }
        if (field.secret) {
            IconButton(onClick = { reveal = !reveal }) {
                Icon(if (reveal) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, contentDescription = "Show or hide")
            }
        }
        IconButton(onClick = { copyText(ctx, label, field.value) }) {
            Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy $label", tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun FieldList(fields: List<Field>) {
    SectionCard {
        Column {
            fields.forEachIndexed { i, f ->
                if (i > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                FieldRow(f)
            }
        }
    }
}

@Composable
fun MasterCopyButton(label: String, text: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Button(
        onClick = { copyText(ctx, label, text) },
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
    ) {
        Icon(Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("Master Copy", fontWeight = FontWeight.SemiBold)
    }
}

/** Editable card for one field: name, content, hide toggle, remove. */
@Composable
fun FieldEditorCard(field: Field, onChange: (Field) -> Unit, onRemove: () -> Unit) {
    var reveal by remember { mutableStateOf(false) }
    SectionCard {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = field.name, onValueChange = { onChange(field.copy(name = it)) },
                label = { Text("Field name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            )
            OutlinedTextField(
                value = field.value, onValueChange = { onChange(field.copy(value = it)) },
                label = { Text("Content") }, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (field.secret && !reveal) PasswordVisualTransformation() else VisualTransformation.None,
                trailingIcon = if (field.secret) {
                    {
                        IconButton(onClick = { reveal = !reveal }) {
                            Icon(if (reveal) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, contentDescription = "Show or hide")
                        }
                    }
                } else null,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = field.secret, onCheckedChange = { onChange(field.copy(secret = it)) })
                Text("Hide content (password)", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onRemove) {
                    Icon(Icons.Outlined.Delete, contentDescription = "Remove field", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
