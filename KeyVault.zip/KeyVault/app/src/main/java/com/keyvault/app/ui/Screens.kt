@file:OptIn(ExperimentalMaterial3Api::class)

package com.keyvault.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.keyvault.app.data.Account
import com.keyvault.app.data.Field
import com.keyvault.app.data.Note
import com.keyvault.app.data.VaultViewModel
import com.keyvault.app.data.masterText

// ------------------------------------------------------------------ Lock screen

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(88.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Outlined.Lock, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer) }
        Spacer(Modifier.height(24.dp))
        Text("KeyVault is locked", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Use your phone's screen lock (PIN, pattern, password or fingerprint) to open.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = onUnlock, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Unlock", fontWeight = FontWeight.SemiBold)
        }
    }
}

// ------------------------------------------------------------------ Navigation

private sealed interface Route {
    data object Home : Route
    data class AccountView(val id: String) : Route
    data class AccountEdit(val id: String?) : Route
    data class NoteEdit(val id: String?) : Route
    data object ProfileEdit : Route
}

@Composable
fun AppRoot(vm: VaultViewModel, onLock: () -> Unit) {
    var route by remember { mutableStateOf<Route>(Route.Home) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val back: () -> Unit = {
        route = when (val r = route) {
            is Route.AccountEdit -> if (r.id != null && vm.account(r.id) != null) Route.AccountView(r.id) else Route.Home
            else -> Route.Home
        }
    }
    BackHandler(enabled = route != Route.Home, onBack = back)

    when (val r = route) {
        Route.Home -> HomeScreen(
            vm, tab, onTab = { tab = it }, onLock = onLock,
            openAccount = { route = Route.AccountView(it) },
            newAccount = { route = Route.AccountEdit(null) },
            openNote = { route = Route.NoteEdit(it) },
            editProfile = { route = Route.ProfileEdit },
        )
        is Route.AccountView -> {
            val acc = vm.account(r.id)
            if (acc == null) LaunchedEffect(r.id) { route = Route.Home }
            else AccountViewScreen(acc, onBack = back, onEdit = { route = Route.AccountEdit(acc.id) },
                onDelete = { vm.deleteAccount(acc.id); route = Route.Home })
        }
        is Route.AccountEdit -> AccountEditScreen(
            initial = r.id?.let { vm.account(it) }, onBack = back,
            onSave = { vm.saveAccount(it); route = Route.AccountView(it.id) },
        )
        is Route.NoteEdit -> NoteEditScreen(
            initial = r.id?.let { vm.note(it) }, onBack = back,
            onSave = { vm.saveNote(it); route = Route.Home },
            onDelete = { vm.deleteNote(it); route = Route.Home },
        )
        Route.ProfileEdit -> FieldsEditScreen(
            screenTitle = "Edit Profile", initial = vm.data.profile, onBack = back,
            onSave = { vm.saveProfile(it); route = Route.Home },
        )
    }
}

// ------------------------------------------------------------------ Home (3 tabs)

private data class Tab(val label: String, val icon: ImageVector)
private val tabs = listOf(
    Tab("User IDs", Icons.Outlined.Key),
    Tab("Notes", Icons.Outlined.Description),
    Tab("Profile", Icons.Outlined.Person),
)

@Composable
private fun HomeScreen(
    vm: VaultViewModel, tab: Int, onTab: (Int) -> Unit, onLock: () -> Unit,
    openAccount: (String) -> Unit, newAccount: () -> Unit, openNote: (String?) -> Unit, editProfile: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tabs[tab].label, fontWeight = FontWeight.SemiBold) },
                actions = { IconButton(onClick = onLock) { Icon(Icons.Outlined.Lock, "Lock now") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { onTab(i) },
                        icon = { Icon(t.icon, null) }, label = { Text(t.label) })
                }
            }
        },
        floatingActionButton = {
            if (tab < 2) FloatingActionButton(
                onClick = { if (tab == 0) newAccount() else openNote(null) },
                containerColor = MaterialTheme.colorScheme.primary,
            ) { Icon(Icons.Outlined.Add, "Add") }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> AccountsTab(vm.data.accounts, openAccount)
                1 -> NotesTab(vm.data.notes, openNote)
                else -> ProfileTab(vm, editProfile, onLock)
            }
        }
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, hint: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(hint, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun AccountsTab(accounts: List<Account>, open: (String) -> Unit) {
    val ctx = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    if (accounts.isEmpty()) {
        EmptyState(Icons.Outlined.Key, "No user IDs yet", "Tap + to save your first login.")
        return
    }
    val shown = accounts.filter {
        query.isBlank() || it.title.contains(query, true) || it.fields.any { f -> !f.secret && f.value.contains(query, true) }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search") }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
            )
        }
        items(shown, key = { it.id }) { a ->
            SectionCard(Modifier.clickable { open(a.id) }) {
                Row(Modifier.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(a.title)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(a.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val sub = a.fields.firstOrNull { !it.secret && it.value.isNotBlank() }?.value ?: "${a.fields.size} fields"
                        Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    IconButton(onClick = { copyText(ctx, a.title, masterText(a.title, a.fields)) }) {
                        Icon(Icons.Outlined.ContentCopy, "Master copy", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun Avatar(title: String) {
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Text(title.trim().take(1).uppercase().ifEmpty { "?" }, color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun NotesTab(notes: List<Note>, open: (String?) -> Unit) {
    val ctx = LocalContext.current
    if (notes.isEmpty()) {
        EmptyState(Icons.Outlined.Description, "No notes yet", "Tap + to keep any text safely.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(notes, key = { it.id }) { n ->
            SectionCard(Modifier.clickable { open(n.id) }) {
                Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(n.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (n.body.isNotBlank()) Text(n.body, maxLines = 3, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    }
                    IconButton(onClick = { copyText(ctx, n.title.ifBlank { "Note" }, n.body) }) {
                        Icon(Icons.Outlined.ContentCopy, "Copy note", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileTab(vm: VaultViewModel, edit: () -> Unit, onLock: () -> Unit) {
    val profile = vm.data.profile
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp, 4.dp, 16.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("My details", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = edit) { Icon(Icons.Outlined.Edit, null, Modifier.size(18.dp)); Spacer(Modifier.size(6.dp)); Text("Edit") }
        }
        if (profile.isEmpty()) Text("No details yet — tap Edit.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        else {
            FieldList(profile)
            MasterCopyButton("Profile", masterText(null, profile))
        }

        Spacer(Modifier.height(8.dp))
        Text("Appearance", style = MaterialTheme.typography.titleMedium)
        val modes = listOf("light" to "Light", "dark" to "Dark", "system" to "Auto")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            modes.forEachIndexed { i, (key, label) ->
                SegmentedButton(
                    selected = vm.themeMode == key, onClick = { vm.setTheme(key) },
                    shape = SegmentedButtonDefaults.itemShape(i, modes.size),
                ) { Text(label) }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("Security", style = MaterialTheme.typography.titleMedium)
        SectionCard {
            Text(
                "Data is encrypted on this phone only (AES-256, Android Keystore). " +
                    "The app locks when you leave it and screenshots are blocked. " +
                    "Uninstalling the app deletes all saved data.",
                Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        OutlinedButton(onClick = onLock, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Outlined.Lock, null, Modifier.size(18.dp)); Spacer(Modifier.size(8.dp)); Text("Lock now")
        }
    }
}

// ------------------------------------------------------------------ Account view / edit

@Composable
private fun BackBar(title: String, onBack: () -> Unit, actions: @Composable () -> Unit = {}) {
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back") } },
        actions = { actions() },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
    )
}

@Composable
private fun ConfirmDelete(what: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete $what?") },
        text = { Text("This cannot be undone.") },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun AccountViewScreen(acc: Account, onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    var askDelete by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        BackBar(acc.title, onBack) {
            IconButton(onClick = onEdit) { Icon(Icons.Outlined.Edit, "Edit") }
            IconButton(onClick = { askDelete = true }) { Icon(Icons.Outlined.Delete, "Delete") }
        }
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            MasterCopyButton(acc.title, masterText(acc.title, acc.fields))
            Text("Tap any line to copy it", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (acc.fields.isEmpty()) Text("No fields. Tap Edit to add some.")
            else FieldList(acc.fields)
        }
    }
    if (askDelete) ConfirmDelete("\"${acc.title}\"", onConfirm = onDelete, onDismiss = { askDelete = false })
}

@Composable
private fun AccountEditScreen(initial: Account?, onBack: () -> Unit, onSave: (Account) -> Unit) {
    var title by rememberSaveable { mutableStateOf(initial?.title ?: "") }
    var titleError by remember { mutableStateOf(false) }
    val fields = remember {
        mutableStateListOf<Field>().apply {
            addAll(initial?.fields ?: listOf(Field(name = "User ID"), Field(name = "Password", secret = true)))
        }
    }
    val save: () -> Unit = {
        if (title.isBlank()) {
            titleError = true
        } else {
            onSave((initial ?: Account()).copy(title = title.trim(), fields = fields.toList()))
        }
    }
    Scaffold(topBar = {
        BackBar(if (initial == null) "New User ID" else "Edit", onBack) {
            IconButton(onClick = save) { Icon(Icons.Outlined.Check, "Save") }
        }
    }) { pad ->
        LazyColumn(
            Modifier.padding(pad).imePadding(),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                OutlinedTextField(
                    value = title, onValueChange = { title = it; titleError = false },
                    label = { Text("Title (e.g. Gmail, Bank, Wi-Fi)") }, singleLine = true, isError = titleError,
                    supportingText = if (titleError) { { Text("Title is required") } } else null,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            fieldEditorItems(fields)
            item { SaveButton(save) }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.fieldEditorItems(fields: MutableList<Field>) {
    itemsIndexed(fields, key = { _, f -> f.id }) { i, f ->
        FieldEditorCard(f, onChange = { fields[i] = it }, onRemove = { fields.removeAt(i) })
    }
    item {
        OutlinedButton(onClick = { fields.add(Field()) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Outlined.Add, null, Modifier.size(18.dp)); Spacer(Modifier.size(8.dp)); Text("Add field")
        }
    }
}

@Composable
private fun SaveButton(onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
        Text("Save", fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FieldsEditScreen(screenTitle: String, initial: List<Field>, onBack: () -> Unit, onSave: (List<Field>) -> Unit) {
    val fields = remember { mutableStateListOf<Field>().apply { addAll(initial) } }
    val save: () -> Unit = { onSave(fields.toList()) }
    Scaffold(topBar = {
        BackBar(screenTitle, onBack) { IconButton(onClick = save) { Icon(Icons.Outlined.Check, "Save") } }
    }) { pad ->
        LazyColumn(
            Modifier.padding(pad).imePadding(),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            fieldEditorItems(fields)
            item { SaveButton(save) }
        }
    }
}

// ------------------------------------------------------------------ Notes

@Composable
private fun NoteEditScreen(initial: Note?, onBack: () -> Unit, onSave: (Note) -> Unit, onDelete: (String) -> Unit) {
    val ctx = LocalContext.current
    var title by rememberSaveable { mutableStateOf(initial?.title ?: "") }
    var body by rememberSaveable { mutableStateOf(initial?.body ?: "") }
    var askDelete by remember { mutableStateOf(false) }
    val save: () -> Unit = {
        if (title.isBlank() && body.isBlank()) onBack()
        else onSave((initial ?: Note()).copy(title = title.trim(), body = body))
    }
    Scaffold(topBar = {
        BackBar(if (initial == null) "New Note" else "Note", onBack) {
            IconButton(onClick = { copyText(ctx, title.ifBlank { "Note" }, body) }) { Icon(Icons.Outlined.ContentCopy, "Copy") }
            if (initial != null) IconButton(onClick = { askDelete = true }) { Icon(Icons.Outlined.Delete, "Delete") }
            IconButton(onClick = save) { Icon(Icons.Outlined.Check, "Save") }
        }
    }) { pad ->
        Column(
            Modifier.padding(pad).imePadding().fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = body, onValueChange = { body = it }, label = { Text("Write anything…") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp),
            )
            SaveButton(save)
        }
    }
    if (askDelete && initial != null) ConfirmDelete("this note", onConfirm = { onDelete(initial.id) }, onDismiss = { askDelete = false })
}
