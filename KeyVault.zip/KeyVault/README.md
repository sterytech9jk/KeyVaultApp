# KeyVault — Android app to save User IDs & Passwords

## Features
- Opens only with your phone's own screen lock (PIN / pattern / password / fingerprint / face). Re-locks when you leave the app.
- **User IDs**: give a title (Gmail, Bank…), add any number of fields (name + content).
  - Tap a field → its content is copied.
  - **Master Copy** → copies the title and every field with its name.
  - "Hide content" checkbox masks passwords (eye icon to show).
  - Search by title.
- **Notes**: keep any text; copy button on each note.
- **Profile**: your own details (name, mobile, email, address… editable), tap to copy, Master Copy.
- **Light / Dark / Auto** theme (Profile tab → Appearance).
- Data is encrypted (AES-256-GCM, key in Android Keystore), stored only on the phone. Screenshots blocked.

## Build the APK
1. Install Android Studio (Ladybug or newer).
2. File → Open → select this `KeyVault` folder. Let Gradle sync (it downloads Gradle 8.9 and the libraries).
3. Phone: enable Developer options → USB debugging, connect, press ▶ Run.
   Or: Build → Build App Bundle(s) / APK(s) → Build APK(s) → install `app/build/outputs/apk/debug/app-debug.apk`.

Min Android 8.0 (API 26).

## Note
Uninstalling the app deletes all saved data (the encryption key is tied to this install).
